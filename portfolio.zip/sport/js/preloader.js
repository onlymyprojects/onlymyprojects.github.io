$(window).on("load", function () {
    setTimeout(function () {
        $('#preloader').addClass('hidden');
        $('#preloader').removeClass('visible');
    }, 1000)
});