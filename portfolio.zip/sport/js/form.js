$('#input1').focus(function () {
	$('#input-text1').css({ "opacity": "1" });
	$('#input1').css({ "border-bottom": "1px solid #C8A060" });
});






$('#input2').focus(function () {
	$('#input-text2').css({ "opacity": "1" });
	$('#input2').css({ "border-bottom": "1px solid #C8A060" });
});






$('#input3').focus(function () {
	$('#input-text3').css({ "opacity": "1" });
	$('#input3').css({ "border-bottom": "1px solid #C8A060" });
});






$('#input1').focusout(function () {
	$('#input-text1').css({ "opacity": "0" });
	$('#input1').css({ "border-bottom": "1px solid #8C8C8C" });
});






$('#input2').focusout(function () {
	$('#input-text2').css({ "opacity": "0" });
	$('#input2').css({ "border-bottom": "1px solid #8C8C8C" });
});






$('#input3').focusout(function () {
	$('#input-text3').css({ "opacity": "0" });
	$('#input3').css({ "border-bottom": "1px solid #8C8C8C" });
});






$("#input1").on('change', function () {
	if (this.value == "") {
		$('#input1').focusout(function () {
			$('#input-text1').css({ "opacity": "0" });
			$('#input1').css({ "border-bottom": "1px solid #8C8C8C" });
		});
	} else {
		$('#input1').focusout(function () {
			$('#input-text1').css({ "opacity": "1" });
			$('#input1').css({ "border-bottom": "1px solid #C8A060" });
		});
	}
});






$("#input2").on('change', function () {
	if (this.value == "") {
		$('#input2').focusout(function () {
			$('#input-text2').css({ "opacity": "0" });
			$('#input2').css({ "border-bottom": "1px solid #8C8C8C" });
		});
	} else {
		$('#input2').focusout(function () {
			$('#input-text2').css({ "opacity": "1" });
			$('#input2').css({ "border-bottom": "1px solid #C8A060" });
		});
	}
});






$("#input3").on('change', function () {
	if (this.value == "") {
		$('#input3').focusout(function () {
			$('#input-text3').css({ "opacity": "0" });
			$('#input3').css({ "border-bottom": "1px solid #8C8C8C" });
		});
	} else {
		$('#input3').focusout(function () {
			$('#input-text3').css({ "opacity": "1" });
			$('#input3').css({ "border-bottom": "1px solid #C8A060" });
		});
	}
});





var a = 0;
$('#lalala').click(function() {
	if (a == 0) {
		$('#lalala').css({'transition': '1s', 'width': '15cm', 'height': '15cm'});
		a = 1;
		return a;
	}
	if (a == 1) {
		$('#lalala').css({'transition': '1s', 'width': '5cm', 'height': '5cm'});
		a = 0;
		return a;
	}
});





$("#input11").on('input', function () {
	$('#input11-p').text(this.value);
});





// function readURL(input) {
//     if (input.files && input.files[0]) {
//         var reader = new FileReader();

//         reader.onload = function (e) {
//             $('#input9-img').attr('src', e.target.result);
//         }

//         reader.readAsDataURL(input.files[0]);
//     }
// }
// $("#input9").change(function(){
//     readURL(this);
// });