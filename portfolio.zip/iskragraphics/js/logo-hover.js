$(document).ready(function() {
	$('.i1').hover(function() {
		$('.i1').attr('src', 'img/ecoride-hover.png');
	});
	$('.i1').mouseout(function() {
		$('.i1').attr('src', 'img/ecoride-passive.png');
	});

	$('.i2').hover(function() {
		$('.i2').attr('src', 'img/rmetre-hover.png');
	});
	$('.i2').mouseout(function() {
		$('.i2').attr('src', 'img/rmetre-passive.png');
	});

	$('.i3').hover(function() {
		$('.i3').attr('src', 'img/yetikids-hover.png');
	});
	$('.i3').mouseout(function() {
		$('.i3').attr('src', 'img/yetikids-passive.png');
	});

	$('.i4').hover(function() {
		$('.i4').attr('src', 'img/restavrator-hover.png');
	});
	$('.i4').mouseout(function() {
		$('.i4').attr('src', 'img/restavrator-passive.png');
	});

	$('.i5').hover(function() {
		$('.i5').attr('src', 'img/odyssey-hover.png');
	});
	$('.i5').mouseout(function() {
		$('.i5').attr('src', 'img/odyssey-passive.png');
	});

	$('.i6').hover(function() {
		$('.i6').attr('src', 'img/avigo-hover.png');
	});
	$('.i6').mouseout(function() {
		$('.i6').attr('src', 'img/avigo-passive.png');
	});

	$('.i7').hover(function() {
		$('.i7').attr('src', 'img/sivart-hover.png');
	});
	$('.i7').mouseout(function() {
		$('.i7').attr('src', 'img/sivart-passive.png');
	});

	$('.i8').hover(function() {
		$('.i8').attr('src', 'img/planar-hover.png');
	});
	$('.i8').mouseout(function() {
		$('.i8').attr('src', 'img/planar-passive.png');
	});

	$('.i9').hover(function() {
		$('.i9').attr('src', 'img/porter-hover.png');
	});
	$('.i9').mouseout(function() {
		$('.i9').attr('src', 'img/porter-passive.png');
	});

	$('.i10').hover(function() {
		$('.i10').attr('src', 'img/magic-hover.png');
	});
	$('.i10').mouseout(function() {
		$('.i10').attr('src', 'img/magic-passive.png');
	});

	$('.i11').hover(function() {
		$('.i11').attr('src', 'img/hive-hover.png');
	});
	$('.i11').mouseout(function() {
		$('.i11').attr('src', 'img/hive-passive.png');
	});

	$('.i12').hover(function() {
		$('.i12').attr('src', 'img/whaleberry-hover.png');
	});
	$('.i12').mouseout(function() {
		$('.i12').attr('src', 'img/whaleberry-passive.png');
	});

	$('.i13').hover(function() {
		$('.i13').attr('src', 'img/everest-hover.png');
	});
	$('.i13').mouseout(function() {
		$('.i13').attr('src', 'img/everest-passive.png');
	});

	$('.i14').hover(function() {
		$('.i14').attr('src', 'img/adelun-hover.png');
	});
	$('.i14').mouseout(function() {
		$('.i14').attr('src', 'img/adelun-passive.png');
	});

	$('.i15').hover(function() {
		$('.i15').attr('src', 'img/tenno-hover.png');
	});
	$('.i15').mouseout(function() {
		$('.i15').attr('src', 'img/tenno-passive.png');
	});

	$('.i16').hover(function() {
		$('.i16').attr('src', 'img/vitamins-hover.png');
	});
	$('.i16').mouseout(function() {
		$('.i16').attr('src', 'img/vitamins-passive.png');
	});
});